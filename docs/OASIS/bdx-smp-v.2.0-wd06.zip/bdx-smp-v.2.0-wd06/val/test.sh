#
sh validate.sh ../xsd/ServiceGroup-2.0.xsd simpleGroupExample.xml
sh validate.sh ../xsd/ServiceGroup-2.0.xsd simpleGroupExampleFailSyntax.xml
sh validate.sh ../xsd/ServiceGroup-2.0.xsd simpleGroupExampleFailModel.xml
sh validate.sh ../xsd/ServiceGroup-2.0.xsd simpleGroupExampleExtension.xml
sh validate.sh ../xsd/ServiceMetadata-2.0.xsd simpleMetadataExample.xml
