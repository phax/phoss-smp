package com.edicom.edicomnet.asxserver.peppolservices.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import com.edicom.edicomnet.asxserver.peppolservices.modelmethods.ModelHelper;
import com.helger.peppol.identifier.CIdentifier;
import com.helger.peppol.identifier.participant.SimpleParticipantIdentifier;

@Entity
@Table(name = "EASSMPSERVICEGROUP", uniqueConstraints = @UniqueConstraint(columnNames={"PART_IDENTIFIER_SCHEMA", "PART_IDENTIFIER"}))
public class EasSMPServiceGroup {

	private int groupId;
	private String participantIdentifierScheme;
	private String participantIdentifier;
	private String extension;
	private EasSMPUser owner;
	
	private Set<EasSMPServiceMetadata> easSMPServiceMetadatas = new HashSet<>(0);
	
	//Configuración del buzón EBI del interlocutor
	private Map<String,String> serviceGroupConfig = new HashMap<>(0);

	
	public EasSMPServiceGroup() {
		/*
		 * Needed constructor for hibernate
		 */
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "GROUP_ID", unique = true, nullable = false)
	public int getGroupId() {
		return this.groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	@Column(name = "PART_IDENTIFIER_SCHEMA", nullable = false, length = CIdentifier.MAX_IDENTIFIER_SCHEME_LENGTH)
	public String getParticipantIdentifierScheme() {
		return participantIdentifierScheme;
	}

	public void setParticipantIdentifierScheme(final String sBusinessIdentifierScheme) {
		participantIdentifierScheme = ModelHelper.getUnifiedParticipantDBValue(sBusinessIdentifierScheme);
	}

	@Column(name = "PART_IDENTIFIER", nullable = false, length = CIdentifier.MAX_PARTICIPANT_IDENTIFIER_VALUE_LENGTH)
	public String getParticipantIdentifier() {
		return participantIdentifier;
	}

	public void setParticipantIdentifier(final String sBusinessIdentifier) {
		participantIdentifier = ModelHelper.getUnifiedParticipantDBValue(sBusinessIdentifier);
	}

	@Lob
	@Column(name = "EXTENSION", length = 65535)
	public String getExtension() {
		return this.extension;
	}

	public void setExtension(@Nullable final String extension) {
		this.extension = extension;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "OWNER")
	public EasSMPUser getOwner() {
		return this.owner;
	}

	public void setOwner(EasSMPUser owner) {
		this.owner = owner;
	}
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "serviceGroup", cascade = { CascadeType.ALL })
	public Set<EasSMPServiceMetadata> getEasSMPServiceMetadatas() {
		return this.easSMPServiceMetadatas;
	}

	public void setEasSMPServiceMetadatas(Set<EasSMPServiceMetadata> easSMPServiceMetadatas) {
		this.easSMPServiceMetadatas = easSMPServiceMetadatas;
	}

	@Transient
	@Nonnull
	public SimpleParticipantIdentifier getAsBusinessIdentifier() {
		return new SimpleParticipantIdentifier(participantIdentifierScheme, participantIdentifier);
	}

	@ElementCollection(targetClass = String.class, fetch = FetchType.EAGER)
 	@JoinTable(	name = "EASSMPSERVICEGROUPCONFIG", 
 						joinColumns = @JoinColumn(name = "SERVICEGROUP")
     			)
    @MapKeyColumn(name = "PROPERTY_NAME")
    @Column(name = "PROPERTY_VALUE")
	public Map<String, String> getServiceGroupConfig() {
		return serviceGroupConfig;
	}

	public void setServiceGroupConfig(Map<String, String> serviceGroupConfig) {
		this.serviceGroupConfig = serviceGroupConfig;
	}
}
