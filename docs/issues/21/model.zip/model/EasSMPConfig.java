package com.edicom.edicomnet.asxserver.peppolservices.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cache;

import com.edicom.edicomnet.asxserver.model.Eascerts;
import com.edicom.edicomnet.asxserver.peppolservices.modelmethods.CertUsage;

@Entity
@Cache(usage = org.hibernate.annotations.CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Table(name = "EASSMPCONFIG")
public class EasSMPConfig {

	private int smpConfigId;
	
	private boolean forceRoot;
	private String publicUrl;
	private boolean writableAPIDisabled;
	private boolean writeToSML;
	private String SMLUrl;
	private String SMKUrl;
	private String SMPId;
		
	private Set<EasSMPConfigCert> easSMPConfigCerts = new HashSet<>(0);
	
	public EasSMPConfig() {
		//Hibernate
	}
	
	public EasSMPConfig(boolean forceRoot, String publicUrl, boolean writableAPIDisabled,
			boolean writeToSML, String sMLUrl, String sMKUrl, String sMPId) {
		super();
		this.forceRoot = forceRoot;
		this.publicUrl = publicUrl;
		this.writableAPIDisabled = writableAPIDisabled;
		this.writeToSML = writeToSML;
		SMLUrl = sMLUrl;
		SMKUrl = sMKUrl;
		SMPId = sMPId;
	}
	
	@Id
	@Column(name = "SMP_CONFIG_ID", unique = true, nullable = false)
	public int getSmpConfigId() {
		return this.smpConfigId;
	}

	public void setSmpConfigId(int smpConfigId) {
		this.smpConfigId = smpConfigId;
	}

	/**
	 * @return <code>true</code> if all paths should be forced to the ROOT ("/")
	 *         context, <code>false</code> if the context should remain as it
	 *         is.
	 */
	@Column(name = "FORCE_ROOT", nullable = false)
	public boolean isForceRoot() {
		return forceRoot;
	}

	public void setForceRoot(boolean forceRoot) {
		this.forceRoot = forceRoot;
	}

	/**
	 * @return The server URL that should be used to create absolute URLs inside
	 *         the application. This may be helpful when running on a proxied
	 *         Tomcat behind a web server.
	 */
	@Column(name = "PUBLIC_URL", nullable = false, length = 256)
	public String getPublicUrl() {
		return publicUrl;
	}

	public void setPublicUrl(String publicUrl) {
		this.publicUrl = publicUrl;
	}

	/**
	 * Check if the writable parts of the REST API are disabled. If this is the
	 * case, only the read-only part of the API can be used. The writable REST
	 * API will return an HTTP 404 error.
	 *
	 * @return <code>true</code> if it is disabled, <code>false</code> if it is
	 *         enabled. By the default the writable API is enabled.
	 */
	@Column(name = "WRITABLE_API_DISABLED", nullable = false)
	public boolean isWritableAPIDisabled() {
		return writableAPIDisabled;
	}

	public void setWritableAPIDisabled(boolean writableAPIDisabled) {
		this.writableAPIDisabled = writableAPIDisabled;
	}

	/**
	 * @return <code>true</code> if the SML connection is active,
	 *         <code>false</code> if not. 
	 */
	@Column(name = "WRITE_TO_SML", nullable = false)
	public boolean isWriteToSML() {
		return writeToSML;
	}

	public void setWriteToSML(boolean writeToSML) {
		this.writeToSML = writeToSML;
	}

	/**
	 * @return The SML URL to use. Only relevant when {@link #isWriteToSML()} is
	 *         <code>true</code>.
	 */
	@Column(name = "SML_URL", nullable = false, length = 256)
	public String getSMLUrl() {
		return SMLUrl;
	}

	public void setSMLUrl(String sMLUrl) {
		SMLUrl = sMLUrl;
	}
	
	/**
	 * @return The SMK URL to use. Only relevant when {@link #isWriteToSML()} is
	 *         <code>true</code>.
	 */
	@Column(name = "SMK_URL", nullable = false, length = 256)
	public String getSMKUrl() {
		return SMKUrl;
	}

	public void setSMKUrl(String sMKUrl) {
		SMKUrl = sMKUrl;
	}

	/**
	 * @return The SMP-ID to be used in the SML. Only relevant when
	 *         {@link #isWriteToSML()} is <code>true</code>.
	 */
	@Column(name = "SMP_ID", nullable = false, length = 256)
	public String getSMPId() {
		return SMPId;
	}

	public void setSMPId(String sMPId) {
		SMPId = sMPId;
	}

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "easSMPConfig", cascade = { CascadeType.ALL })
	public Set<EasSMPConfigCert> getEasSMPConfigCerts() {
		return this.easSMPConfigCerts;
	}

	public void setEasSMPConfigCerts(Set<EasSMPConfigCert> easSMPConfigCerts) {
		this.easSMPConfigCerts = easSMPConfigCerts;
	}
	
	@Transient
	@Nonnull
	public Eascerts getPrivateSMPCert() {
		if (easSMPConfigCerts != null) {
			for (EasSMPConfigCert easSMPConfigCert : easSMPConfigCerts) {
				if (easSMPConfigCert.getCertificateUsage() == CertUsage.SMP_PRIVATE_CERT.getId()) {
					return easSMPConfigCert.getCertificate();
				}
			} 
		}
		return null;
	}
	
	@Transient
	@Nonnull
	public List<Eascerts> getPeppolCerts(CertUsage certUsage) {
		List<Eascerts> caCerts = new ArrayList<>();
		if (easSMPConfigCerts != null) {
			for (EasSMPConfigCert easSMPConfigCert : easSMPConfigCerts) {
				if (easSMPConfigCert.getCertificateUsage() == certUsage.getId()) {
					caCerts.add(easSMPConfigCert.getCertificate());
				}
			} 
		}
		return caCerts;
	}
}
