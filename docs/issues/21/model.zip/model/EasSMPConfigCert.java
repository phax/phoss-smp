package com.edicom.edicomnet.asxserver.peppolservices.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;

import com.edicom.edicomnet.asxserver.model.Eascerts;

@Entity
@Cache(usage = org.hibernate.annotations.CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Table(name = "EASSMPCONFIGCERT")
public class EasSMPConfigCert {
	
	private int configCertId;
	
	private int certificateUsage;
	
	private EasSMPConfig easSMPConfig;
	private Eascerts certificate;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CONFIGCERT_ID", unique = true, nullable = false)
	public int getConfigCertId() {
		return this.configCertId;
	}

	public void setConfigCertId(int configCertId) {
		this.configCertId = configCertId;
	}
	
	@Column(name = "CERTIFICATE_USAGE", nullable = false)
	public int getCertificateUsage() {
		return this.certificateUsage;
	}

	public void setCertificateUsage(int certificateUsage) {
		this.certificateUsage = certificateUsage;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CERT")
	public Eascerts getCertificate() {
		return this.certificate;
	}

	public void setCertificate(Eascerts certificate) {
		this.certificate = certificate;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CONFIG")
	public EasSMPConfig getEasSMPConfig() {
		return this.easSMPConfig;
	}

	public void setEasSMPConfig(EasSMPConfig easSMPConfig) {
		this.easSMPConfig = easSMPConfig;
	}
	
}
