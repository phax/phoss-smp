package com.edicom.edicomnet.asxserver.peppolservices.model;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.edicom.edicomnet.asxserver.model.Eascerts;

@Entity
@Table(name = "EASSMPSERVICEMETADATA", uniqueConstraints = @UniqueConstraint(columnNames = { "SERVICE_GROUP",
		"DOCUMENT_TYPE_ID", "PROCESS_ID" }))
public class EasSMPServiceMetadata {

	private int metadataId;

	private String redirectionUrl;
	private boolean mustRedirect = false;
	private Eascerts certificate;
	private EasSMPServiceGroup serviceGroup;

	private EasSMPProcess process;
	private EasSMPEndpoint endpoint;
	private EasSMPDocumentType documentType;

	// Configuración del buzón EBI del tipo de mensaje
	private Map<String, String> serviceMetadataConfig = new HashMap<>(0);

	private String docExtension;
	private String procExtension;
	private String endpointExtension;

	public EasSMPServiceMetadata() {
		// Empty constructor needed by hibernate
	}

	public EasSMPServiceMetadata(@Nonnull final EasSMPServiceGroup serviceGroup, @Nullable final String docExtension,
			@Nullable final String procExtension, @Nullable final String endpointExtension) {
		this.serviceGroup = serviceGroup;
		this.docExtension = docExtension;
		this.procExtension = procExtension;
		this.endpointExtension = endpointExtension;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "METADATA_ID", unique = true, nullable = false)
	public int getMetadataId() {
		return this.metadataId;
	}

	public void setMetadataId(int metadataId) {
		this.metadataId = metadataId;
	}

	@Column(name = "REDIRECTION_URL", length = 256)
	public String getRedirectionUrl() {
		return this.redirectionUrl;
	}

	public void setRedirectionUrl(final String redirectionUrl) {
		this.redirectionUrl = redirectionUrl;
	}

	@Column(name = "MUST_REDIRECT", nullable = false)
	public boolean getMustRedirect() {
		return this.mustRedirect;
	}

	public void setMustRedirect(final boolean mustRedirect) {
		this.mustRedirect = mustRedirect;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CERT")
	public Eascerts getCertificate() {
		return this.certificate;
	}

	public void setCertificate(Eascerts certificate) {
		this.certificate = certificate;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SERVICE_GROUP")
	public EasSMPServiceGroup getServiceGroup() {
		return this.serviceGroup;
	}

	public void setServiceGroup(EasSMPServiceGroup serviceGroup) {
		this.serviceGroup = serviceGroup;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "DOCUMENT_TYPE_ID")
	public EasSMPDocumentType getDocumentType() {
		return this.documentType;
	}

	public void setDocumentType(EasSMPDocumentType documentType) {
		this.documentType = documentType;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "PROCESS_ID")
	public EasSMPProcess getProcess() {
		return this.process;
	}

	public void setProcess(EasSMPProcess process) {
		this.process = process;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "ENDPOINT_ID")
	public EasSMPEndpoint getEndpoint() {
		return this.endpoint;
	}

	public void setEndpoint(EasSMPEndpoint endpoint) {
		this.endpoint = endpoint;
	}

	@Lob
	@Column(name = "DOC_EXTENSION", length = 65535)
	public String getDocExtension() {
		return this.docExtension;
	}

	public void setDocExtension(@Nullable final String docExtension) {
		this.docExtension = docExtension;
	}

	@Lob
	@Column(name = "PROC_EXTENSION", length = 65535)
	public String getProcExtension() {
		return this.procExtension;
	}

	public void setProcExtension(@Nullable final String procExtension) {
		this.procExtension = procExtension;
	}

	@Lob
	@Column(name = "ENDPOINT_EXTENSION", length = 65535)
	public String getEndpointExtension() {
		return this.endpointExtension;
	}

	public void setEndpointExtension(@Nullable final String endpointExtension) {
		this.endpointExtension = endpointExtension;
	}

	@ElementCollection(targetClass = String.class, fetch = FetchType.EAGER)
	@JoinTable(name = "EASSMPSERVICEMETADATACONFIG", joinColumns = @JoinColumn(name = "SERVICEMETADATA"))
	@MapKeyColumn(name = "PROPERTY_NAME")
	@Column(name = "PROPERTY_VALUE")
	public Map<String, String> getServiceMetadataConfig() {
		return serviceMetadataConfig;
	}

	public void setServiceMetadataConfig(Map<String, String> serviceMetadataConfig) {
		this.serviceMetadataConfig = serviceMetadataConfig;
	}

}
