package com.edicom.edicomnet.asxserver.peppolservices.model;

import java.util.HashSet;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import com.helger.peppol.identifier.CIdentifier;
import com.helger.peppol.identifier.ProcessIdentifierType;
import com.helger.peppol.identifier.process.SimpleProcessIdentifier;

@Entity
@Table(name = "EASSMPPROCESS", uniqueConstraints = @UniqueConstraint(columnNames={"PROCESS_IDENTIFIER_SCHEME", "PROCESS_IDENTIFIER"}))
public class EasSMPProcess {

	private int processId;

	private String processIdentifierScheme;
	private String processIdentifier;

	private Set<EasSMPServiceMetadata> easSMPServiceMetadatas = new HashSet<>(0);
	
	public EasSMPProcess() {
		//Empty constructor for hibernate
	}
	
	public EasSMPProcess (String processIdentifierScheme, String processIdentifier) {
		this.processIdentifierScheme=processIdentifierScheme;
		this.processIdentifier=processIdentifier;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PROCESS_ID", unique = true, nullable = false)
	public int getProcessId() {
		return this.processId;
	}

	public void setProcessId(int processId) {
		this.processId = processId;
	}

	@Column(name = "PROCESS_IDENTIFIER_SCHEME", nullable = false, length = CIdentifier.MAX_IDENTIFIER_SCHEME_LENGTH)
	public String getProcessIdentifierScheme() {
		return this.processIdentifierScheme;
	}

	public void setProcessIdentifierScheme(final String processIdentifierScheme) {
		this.processIdentifierScheme = processIdentifierScheme;
	}

	@Column(name = "PROCESS_IDENTIFIER", nullable = false, length = CIdentifier.MAX_PROCESS_IDENTIFIER_VALUE_LENGTH)
	public String getProcessIdentifier() {
		return this.processIdentifier;
	}

	public void setProcessIdentifier(final String processIdentifier) {
		this.processIdentifier = processIdentifier;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "process")
	public Set<EasSMPServiceMetadata> getEasSMPServiceMetadatas() {
		return this.easSMPServiceMetadatas;
	}

	public void setEasSMPServiceMetadatas(Set<EasSMPServiceMetadata> easSMPServiceMetadatas) {
		this.easSMPServiceMetadatas = easSMPServiceMetadatas;
	}

	@Transient
	@Nonnull
	public ProcessIdentifierType getAsProcessIdentifier() {
		return new SimpleProcessIdentifier(processIdentifierScheme, processIdentifier);
	}
}
