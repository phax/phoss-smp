package com.edicom.edicomnet.asxserver.peppolservices.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.edicom.edicomnet.asxserver.model.Eascerts;

@Entity
@Table(name = "EASSMPENDPOINT")
public class EasSMPEndpoint {

	private int endpointId;

	private String transportProfile;
	private String endpointReference;
	private boolean requireBusinessLevelSignature;
	private String minimumAuthenticationLevel;
	private Date serviceActivationDate;
	private Date serviceExpirationDate;
	private Eascerts certificate;
	private String serviceDescription;
	private String technicalContactUrl;
	private String technicalInformationUrl;
	
	private Set<EasSMPServiceMetadata> easSMPServiceMetadatas = new HashSet<>(0);

	public EasSMPEndpoint() {
		// Empty constructor needed for hibernate
	}
	
	public EasSMPEndpoint(String transportProfile, String endpointReference,
			boolean requireBusinessLevelSignature, String minimumAuthenticationLevel,
			Date serviceActivationDate, Date serviceExpirationDate, Eascerts certificate,
			String serviceDescription, String technicalContactUrl, String technicalInformationUrl) {
		super();
		this.transportProfile = transportProfile;
		this.endpointReference = endpointReference;
		this.requireBusinessLevelSignature = requireBusinessLevelSignature;
		this.minimumAuthenticationLevel = minimumAuthenticationLevel;
		this.serviceActivationDate = serviceActivationDate;
		this.serviceExpirationDate = serviceExpirationDate;
		this.certificate = certificate;
		this.serviceDescription = serviceDescription;
		this.technicalContactUrl = technicalContactUrl;
		this.technicalInformationUrl = technicalInformationUrl;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ENDPOINT_ID", unique = true, nullable = false)
	public int getEndpointId() {
		return this.endpointId;
	}

	public void setEndpointId(int endpointId) {
		this.endpointId = endpointId;
	}

	@Column(name = "TRANSPORT_PROFILE", nullable = false, length = 255)
	public String getTransportProfile() {
		return this.transportProfile;
	}

	public void setTransportProfile(final String transportProfile) {
		this.transportProfile = transportProfile;
	}

	@Column(name = "ENDPOINT_REFERENCE", nullable = false, length = 256)
	public String getEndpointReference() {
		return endpointReference;
	}

	public void setEndpointReference(final String endpointReference) {
		this.endpointReference = endpointReference;
	}

	@Column(name = "REQUIRE_BUSINESS_LEVEL_SIGNATURE", nullable = false)
	public boolean isRequireBusinessLevelSignature() {
		return this.requireBusinessLevelSignature;
	}

	public void setRequireBusinessLevelSignature(final boolean requireBusinessLevelSignature) {
		this.requireBusinessLevelSignature = requireBusinessLevelSignature;
	}

	@Column(name = "MINIMUN_AUTHENTICATION_LEVEL", length = 256)
	public String getMinimumAuthenticationLevel() {
		return this.minimumAuthenticationLevel;
	}

	public void setMinimumAuthenticationLevel(final String minimumAuthenticationLevel) {
		this.minimumAuthenticationLevel = minimumAuthenticationLevel;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "SERVICE_ACTIVATION_DATE", length = 23)
	public Date getServiceActivationDate() {
		return this.serviceActivationDate;
	}

	public void setServiceActivationDate(final Date serviceActivationDate) {
		this.serviceActivationDate = serviceActivationDate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "SERVICE_EXPIRATION_DATE", length = 23)
	public Date getServiceExpirationDate() {
		return this.serviceExpirationDate;
	}

	public void setServiceExpirationDate(final Date serviceExpirationDate) {
		this.serviceExpirationDate = serviceExpirationDate;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CERT")
	public Eascerts getCertificate() {
		return this.certificate;
	}

	public void setCertificate(Eascerts certificate) {
		this.certificate = certificate;
	}

	@Lob
	@Column(name = "SERVICE_DESCRIPTION", nullable = false, length = 65535)
	public String getServiceDescription() {
		return this.serviceDescription;
	}

	public void setServiceDescription(final String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

	@Column(name = "TECHNICAL_CONTACT_URL", nullable = false, length = 256)
	public String getTechnicalContactUrl() {
		return this.technicalContactUrl;
	}

	public void setTechnicalContactUrl(final String technicalContactUrl) {
		this.technicalContactUrl = technicalContactUrl;
	}

	@Column(name = "TECHNICAL_INFORMATION_URL", length = 256)
	public String getTechnicalInformationUrl() {
		return this.technicalInformationUrl;
	}

	public void setTechnicalInformationUrl(final String technicalInformationUrl) {
		this.technicalInformationUrl = technicalInformationUrl;
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "endpoint")
	public Set<EasSMPServiceMetadata> getEasSMPServiceMetadatas() {
		return this.easSMPServiceMetadatas;
	}

	public void setEasSMPServiceMetadatas(Set<EasSMPServiceMetadata> easSMPServiceMetadatas) {
		this.easSMPServiceMetadatas = easSMPServiceMetadatas;
	}

}
