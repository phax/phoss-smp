package com.edicom.edicomnet.asxserver.peppolservices.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "EASSMPUSER")
public class EasSMPUser{

	private int userId;
	private String password;
	private String userName;
	private String role;
	
	
	private Set<EasSMPServiceGroup> easSMPServiceGroups = new HashSet<>(0);

	public EasSMPUser() {
		//Hibernate constructor
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "USER_ID", unique = true, nullable = false)
	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Column(name = "PASSWORD")
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "USERNAME", unique = true)
	public String getUserName() {
		return userName;
	}

	public void setUserName(String username) {
		this.userName = username;
	}
	@Column(name = "ROLE")
	public String getRole() {
		return role;
	}
	
	public void setRole(String role) {
		this.role = role;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "owner", cascade = { CascadeType.ALL })
	public Set<EasSMPServiceGroup> getEasSMPServiceGroups() {
		return this.easSMPServiceGroups;
	}

	public void setEasSMPServiceGroups(Set<EasSMPServiceGroup> easSMPServiceGroups) {
		this.easSMPServiceGroups = easSMPServiceGroups;
	}
}
