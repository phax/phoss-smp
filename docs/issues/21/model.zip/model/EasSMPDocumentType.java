package com.edicom.edicomnet.asxserver.peppolservices.model;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import org.bouncycastle.util.encoders.Base64;

import com.helger.peppol.identifier.CIdentifier;
import com.helger.peppol.identifier.IDocumentTypeIdentifier;
import com.helger.peppol.identifier.doctype.SimpleDocumentTypeIdentifier;

@Entity
@Table(name = "EASSMPDOCUMENTTYPE", uniqueConstraints = @UniqueConstraint(columnNames={"DOC_IDENTIFIER_SCHEME", "DOC_IDENTIFIER_HASH"}))
public class EasSMPDocumentType {
	
	private int documentTypeId;
	
	private String documentTypeIdentifierScheme;
	private String documentTypeIdentifier;
	
	private String documentTypeIdentifierHash;
	
	private Set<EasSMPServiceMetadata> easSMPServiceMetadatas = new HashSet<>(0);
	
	public EasSMPDocumentType() {
		//Hibernate constructor
	}
	
	public EasSMPDocumentType(
			@Nonnull final String documentTypeIdentifierScheme, 
			@Nonnull final String documentTypeIdentifier) {
		this.documentTypeIdentifierScheme=documentTypeIdentifierScheme;
		this.documentTypeIdentifier=documentTypeIdentifier;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DOCUMENT_TYPE_ID", unique = true, nullable = false)
	public int getDocumentTypeId() {
		return this.documentTypeId;
	}

	public void setDocumentTypeId(int documentTypeId) {
		this.documentTypeId = documentTypeId;
	}
	
	@Column(name = "DOC_IDENTIFIER_SCHEME", nullable = false, length = CIdentifier.MAX_IDENTIFIER_SCHEME_LENGTH)
	public String getDocumentTypeIdentifierScheme() {
		return this.documentTypeIdentifierScheme;
	}

	public void setDocumentTypeIdentifierScheme(final String documentTypeIdentifierScheme) {
		this.documentTypeIdentifierScheme = documentTypeIdentifierScheme;
	}

	@Column(name = "DOC_IDENTIFIER", nullable = false, length = CIdentifier.MAX_DOCUMENT_TYPE_IDENTIFIER_VALUE_LENGTH)
	public String getDocumentTypeIdentifier() {
		return this.documentTypeIdentifier;
	}

	public void setDocumentTypeIdentifier(final String documentTypeIdentifier) {
		this.setDocumentTypeIdentifierHash(calculateHash(documentTypeIdentifier));
		this.documentTypeIdentifier = documentTypeIdentifier;
	}
	
	@Column(name = "DOC_IDENTIFIER_HASH", nullable = false, length = 50)
	public String getDocumentTypeIdentifierHash() {
		return this.documentTypeIdentifierHash;
	}

	public void setDocumentTypeIdentifierHash(final String documentTypeIdentifierHash) {
		this.documentTypeIdentifierHash = documentTypeIdentifierHash;
	}
	
	
	@Transient
	public void setDocumentTypeIdentifier(@Nonnull final IDocumentTypeIdentifier aDocTypeID) {
		setDocumentTypeIdentifierScheme(aDocTypeID.getScheme());
		setDocumentTypeIdentifier(aDocTypeID.getValue());
	}

	@Nonnull
	@Transient
	public SimpleDocumentTypeIdentifier getAsDocumentTypeIdentifier() {
		return new SimpleDocumentTypeIdentifier(documentTypeIdentifierScheme, documentTypeIdentifier);
	}
	
	private String calculateHash(String message) {
		try {
			MessageDigest hash = MessageDigest.getInstance("SHA-1", "BC");		
			hash.update(message.getBytes());
			byte[] digest = hash.digest();
		
			return new String(Base64.encode(digest), "ISO-8859-1");
		} catch (UnsupportedEncodingException | NoSuchAlgorithmException | NoSuchProviderException e) {
			e.printStackTrace();
			return "";
		}
	}
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "documentType")
	public Set<EasSMPServiceMetadata> getEasSMPServiceMetadatas() {
		return this.easSMPServiceMetadatas;
	}

	public void setEasSMPServiceMetadatas(Set<EasSMPServiceMetadata> easSMPServiceMetadatas) {
		this.easSMPServiceMetadatas = easSMPServiceMetadatas;
	}

}
